using NUnit.Framework;
using PS.ParserLib.Components;
using System;
using System.Collections.Generic;

namespace PS.XML.ParserLib.Test
{
    public class ParserServiceTest
    {
        public EmployeeResponse _Response { get; set; }

        [SetUp]
        public void Setup()
        {
            _Response = new EmployeeResponse
            {
                ContentItems = new List<Employee>
                {
                    new Employee {
                         Name = "Vaibhav 1",
                         Age = "31",
                         Designation = "Engineer" },
                    new Employee {
                         Name = "Vaibhav 1",
                         Age = "31",
                         Designation = "Engineer" }
                    
                }
            };
        }

        [Test]
        public void Serialize_Response_Test()
        {           
            EmployeeResponse employeeResponse = new EmployeeResponse();
            try
            {
                ParserService<EmployeeResponse> parserService = new ParserService<EmployeeResponse>();
                string xml = parserService.Serialize(_Response);
                employeeResponse = parserService.Deserialize(xml);
            }
            catch (Exception ex)
            {  }
            finally
            {  }
            Assert.IsNotNull(employeeResponse);
        }
    }
}