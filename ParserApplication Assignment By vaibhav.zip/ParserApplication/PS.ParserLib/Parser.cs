﻿using System;
using PS.ParserLib.Components.Common;
using PS.ParserLib.Components;
using PS.ParserLib.Components.Service;

namespace PS.ParserLib
{
    public class Parser<T> : ParseFactory<T>
    {
        public override IParserService<T> GetParsed(string formatType)
        {
            switch (formatType)
            {
                case "xml": return (IParserService<T>)new ParserService<IParserService<T>>();
                default: throw new ApplicationException(string.Format("formatType '{0}' cannot be created", formatType));                    
            }

        }
    }
}
