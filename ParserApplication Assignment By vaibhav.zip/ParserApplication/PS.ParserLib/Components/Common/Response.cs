﻿using System;
using System.Collections.Generic;
using System.Xml.Serialization;

namespace ParserLib.Components.Common
{
	public class Response<T>
	{
		[XmlArray("Employees")]
		public List<T> ContentItems { get; set; }

		public Response()
		{
			this.ContentItems = new List<T>();
		}
	}
}
