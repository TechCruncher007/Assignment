﻿using System;
using ParserLib.Components.Common;

namespace PS.ParserLib.Components
{
    public class EmployeeResponse : Response<Employee>
    {


    }

}
