﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using PS.ParserLib.Components.Service;

namespace PS.ParserLib.Components.Common
{
    public abstract class ParseFactory<T>
    {
        public abstract IParserService<T> GetParsed(string formatType);

    }
}
