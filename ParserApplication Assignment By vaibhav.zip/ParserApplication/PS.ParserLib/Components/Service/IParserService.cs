﻿using System;
using System.Text;
using System.Xml;
using System.Xml.Serialization;

namespace PS.ParserLib.Components.Service
{

    public interface IParserService<T>
    {
        string Serialize(T source);

        string Serialize(T source, XmlSerializerNamespaces namespaces);

        string Serialize(T source, XmlWriterSettings settings);

        string Serialize(T source, XmlSerializerNamespaces namespaces, XmlWriterSettings settings);

        void SerializeToFile(T source, string filename);

        void SerializeToFile(T source, string filename, XmlSerializerNamespaces namespaces);

        void SerializeToFile(T source, string filename, XmlWriterSettings settings);

        void SerializeToFile(T source, string filename, XmlSerializerNamespaces namespaces, XmlWriterSettings settings);

        T Deserialize(string xml);

        T Deserialize(string xml, Encoding encoding);

        T Deserialize(string xml, XmlReaderSettings settings);

        T Deserialize(string xml, Encoding encoding, XmlReaderSettings settings);

        T DeserializeFromFile(string filename);

        T DeserializeFromFile(string filename, XmlReaderSettings settings);


    }
}
