﻿using System;
using System.Xml.Serialization;

namespace PS.ParserLib.Components
{
    [Serializable]
    public class Employee
    {
        public Employee() { }

        [XmlElement("name")]
        public string Name { get; set; }

        [XmlElement("age")]
        public string Age { get; set; }

        [XmlElement("designation")]
        public string Designation { get; set; }

    }
}


