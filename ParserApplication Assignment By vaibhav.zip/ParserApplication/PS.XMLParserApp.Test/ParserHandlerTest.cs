using NUnit.Framework;
using PS.ParserLib.Components;
using PS.XMLParserApp.Components;
using System;
using System.Collections.Generic;

namespace PS.XMLParserApp.Test
{
    public class ParserHandlerTest
    {
        public EmployeeDetailsResponse _Response { get; set; }

        [SetUp]
        public void Setup()
        {
            _Response = new EmployeeDetailsResponse
            {
                ContentItems = new List<EmployeeDetail>
                {
                    new EmployeeDetail {
                        Employee = new Employee{
                         Name = "Vaibhav 1",
                         Age = "31",
                         Designation = "Engineer" },
                         Address = new Address()
                         {
                          DoorNo = "12",
                          State = "Karnataka",
                          Street = "Bellandur",
                          Town = "Bellandur"
                         }
                    },
                    new EmployeeDetail {
                        Employee = new Employee{
                         Name = "Vaibhav 1",
                         Age = "31",
                         Designation = "Engineer" },
                         Address = new Address()
                         {
                          DoorNo = "12",
                          State = "Karnataka",
                          Street = "Bellandur",
                          Town = "Bellandur"
                         }
                    }
                }
            };

           
        }

        [Test]
        public void Serialize_Response_Test()
        {
            EmployeeDetailsResponse employeeDetailsResponse = new EmployeeDetailsResponse();
            try
            {
                ParserService<EmployeeDetailsResponse> parserService = new ParserService<EmployeeDetailsResponse>();
                string xml = parserService.Serialize(_Response);
                employeeDetailsResponse = parserService.Deserialize(xml);
            }
            catch (Exception ex)
            {
            }
            finally
                {            
            }
            Assert.IsNotNull(employeeDetailsResponse);
        }
    }
}