﻿using System;
using System.Xml.Serialization;

namespace PS.XMLParserApp.Components
{
    [Serializable]
    public class Address
    {
        public Address() { }

        [XmlElement("doorNo")]
        public string DoorNo { get; set; }

        [XmlElement("street")]
        public string Street { get; set; }

        [XmlElement("town")]
        public string Town { get; set; }

        [XmlElement("state")]
        public string State { get; set; }

    }
}
