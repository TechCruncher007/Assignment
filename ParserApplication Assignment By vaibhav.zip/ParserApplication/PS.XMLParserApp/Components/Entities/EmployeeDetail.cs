﻿using System;
using System.Xml.Serialization;
using PS.ParserLib.Components;

namespace PS.XMLParserApp.Components
{    
    [System.Xml.Serialization.XmlInclude(typeof(Employee))]
    [Serializable, XmlRoot("employees")]
    [XmlType(TypeName = "employees")]
    public class EmployeeDetail
    {
        public EmployeeDetail() { }

        public EmployeeDetail(Employee Employee, Address Address)
        {
            this.Address = Address;
            this.Employee = Employee;
        }

        [XmlElement("employee")]
        public Employee Employee { get; set; }

        [XmlElement("address")]
        public Address Address { get; set; }

    }
}
