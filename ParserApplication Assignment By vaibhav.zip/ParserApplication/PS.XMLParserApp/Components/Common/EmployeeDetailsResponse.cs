﻿using System;

namespace PS.XMLParserApp.Components
{    
    public class EmployeeDetailsResponse : Response<EmployeeDetail>
    {

    }

}
