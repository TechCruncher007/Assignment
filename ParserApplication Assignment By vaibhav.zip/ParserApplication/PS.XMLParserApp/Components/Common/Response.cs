﻿using System.Collections.Generic;
using System.Xml.Serialization;

namespace PS.XMLParserApp.Components
{
	public class Response<T>
	{
		[XmlArray("employees")]
		public List<T> ContentItems { get; set; }

		public Response()
		{
			this.ContentItems = new List<T>();
		}
	}
}
