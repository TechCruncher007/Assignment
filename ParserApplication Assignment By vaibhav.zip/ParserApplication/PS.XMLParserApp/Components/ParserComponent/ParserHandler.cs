﻿using PS.ParserLib;
using PS.ParserLib.Components;
using PS.XMLParserApp.Components.Service;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PS.XMLParserApp.Components
{
    public class ParserHandler : IParserHandler
    {      
        public void FileReadSerialize(string sourcePath, string destPath)
        {
            ParserService<EmployeeDetail> parserService = new ParserService<EmployeeDetail>();
            EmployeeDetail eventResponse = parserService.DeserializeFromFile(sourcePath);
            parserService.SerializeToFile(eventResponse, destPath);

        }

    }
}
