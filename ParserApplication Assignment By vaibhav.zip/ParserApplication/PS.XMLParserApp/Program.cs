﻿using System;
using System.Collections.Generic;
using System.IO;
using PS.ParserLib.Components;
using PS.XMLParserApp.Components;
using PS.XMLParserApp.Components.Service;

namespace PS.XMLParserApp
{

    /// <summary>
    /// Startup Project 
    /// Passing Source and Destination Infomration
    /// </summary>

    public class Program
    {
        public static void Main(string[] args)
        {
            try
            {
                Console.WriteLine("Intitate the XML-Parser process !!");

                string path = Directory.GetParent(Directory.GetCurrentDirectory()).Parent.Parent.FullName + "\\PS.XMLParserApp\\Files";
                string sourcePath = path + @"\Source\EmployeeDetails.XML";
                string destPath = path + @"\Destination\ExportedEmployeeDetails.XML";

                IParserHandler parserHandler = new ParserHandler();
                parserHandler.FileReadSerialize(sourcePath, destPath);

                Console.WriteLine("XML-Parser process successfully completed !!");
                Console.ReadLine();
            }
            catch (Exception ex)
            {
                Console.WriteLine("XML-Parser process not completed & Exception is " + ex);
            }

        }

    }
}