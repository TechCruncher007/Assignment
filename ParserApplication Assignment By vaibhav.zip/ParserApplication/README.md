1. PS.ParserLib : its is library project 
Responsiboility : Create + read + Update + Delete for employee information
(whole serilization and deserilization in generic format)

Break the project in componentization 
Loose coupling 
SOLID Design principle 
Factory design pattern 
Dependency Injection 
Used generic programing using collection


2. PS.ParseLib.Test
Heving Automated Test Feature


3. PS.XMLParseApp (Concole application as startup project)
Responsiboility : Create + read + Update + Delete for employee + Address information
(whole serilization and deserilization in generic format)

Read the XML file from source location 
Write data in XMl file at destination location which is passing 

Break the project in componentization 
Loose coupling 
SOLID Design principle 
Factory design pattern 
Dependency Injection 
Used generic programing using collection






